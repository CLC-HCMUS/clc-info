#include <iostream.h>

main()
{
    for(;;)
    {
        cout << "Hello World! ";
    }
}